/*
 * main.c
 *
 *  Created on: 15 Apr 2012
 *      Author: Ashley Grealish
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "unlock_codes.h"



int main()
{
	char unlock_code_str	[50];
	char box_id_str	[50];
	char filename_str	[50];
	uint32_t unlock_code = 0;
	uint8_t i;
	FILE* unlock_code_file;

	//Clear screen and print header
	system("cls");
	printf("Generate and tests the unlock codes for the stand alone battery box \n\r");
	printf("---------------------------------------------------------------------------- \n\r");



	//Read in the Box ID
	do {
		box_id_str[0] = '\0';
		while( strlen(box_id_str) <= 1 )	//Checks for nothing entered (endline counts as 1 char)
		{
			printf("Please enter the box ID ( 0 -> 16383 ): \n\r");
			fgets( box_id_str, 256, stdin);
		}
	} while ( set_box_id( atoi(box_id_str) ) );




	printf("What do you want to do? Press 'g' to generate codes, 't' to test codes\n\r");
	if (getchar() == 'g') {

		//Generate the filename for the output file and open it for writing
		box_id_str[strcspn ( box_id_str, "\n" )] = '\0';		//Removes the newline
		strcpy(filename_str, box_id_str);						//Copies the box_id into the filename
		strcat(filename_str, "_unlock_codes.txt");				//Adds the second part and file extension
		printf("Writing to file: %s\n\r", filename_str);		//Prints out update
		unlock_code_file = fopen(filename_str, "w");			//Opens the file for writing

		//Generate codes for given box_id, each unlocks the box for 2 Weeks
		SET_UNLOCK_DAYS(unlock_code, TWO_WEEKS);

		if (unlock_code_file) {

			//Generate 51 unlock codes
			for (i = 0; i < 51; i++){
				SET_UNLOCK_COUNT(unlock_code, i);
				SET_PAD( unlock_code, rand() )
				add_checksum(&unlock_code);
				fprintf(unlock_code_file, "Code %03i: %010u \n\r", i, unlock_code);
			}

			//Generate a final full unlock code
			SET_UNLOCK_DAYS(unlock_code, FULL_UNLOCK);
			add_checksum(&unlock_code);
			fprintf(unlock_code_file, "Full unlock code: %010u \n\r", unlock_code);

			fclose(unlock_code_file);

			printf("%i unlock codes have been written to the output file \n\r", (i+1) );

		}
		else {
			printf("The file could not be opened \n\r");
		}

	}
	else {

		//Read in the unlock code
		unlock_code_str[0] = '\0';
		while( strlen(unlock_code_str) <= 1 )	//Checks for nothing entered (endline counts as 1 char)
		{
			printf("Please enter the unlock code (ten digits): \n\r");
			fgets( unlock_code_str, 50, stdin);
		}

		//Use to strtoul to return an unsigned value
		//atoi returns signed int
		unlock_code = (uint32_t)strtoul(unlock_code_str, NULL, 10);
		printf("%s \n\r", unlock_code_str);
		printf("Unlock code hex: 0x%x \n\r", unlock_code);
		printf("Unlock code: %010u \n\r", unlock_code);


		if (check_checksum(unlock_code)) {
			printf("Code checksum correct \n\r");
			printf("The unlock count is %u \n\r", GET_UNLOCK_COUNT(unlock_code) );
			switch (GET_UNLOCK_DAYS(unlock_code)) {
				case FULL_UNLOCK:
					printf("Full unlock \n\r");
					break;
				case TWO_DAYS:
					printf("Two day unlock \n\r");
					break;
				case FIVE_DAYS:
					printf("Five day unlock \n\r");
					break;
				case SEVEN_DAYS:
					printf("Seven day unlock \n\r");
					break;
				case TWO_WEEKS:
					printf("Two week unlock \n\r");
					break;
				case THREE_WEEKS:
					printf("Three week unlock \n\r");
					break;
				case ONE_MONTH:
					printf("One month unlock \n\r");
					break;
				case TWO_MONTHS:
					printf("Two month unlock \n\r");
					break;
				default:
					printf("Invalid code \n\r");
					break;
			}
		}
		else {
			printf("Code checksum incorrect");
		}

	}


	//Keeps the window open until enter is pressed
	getchar();
	return 0;
}

